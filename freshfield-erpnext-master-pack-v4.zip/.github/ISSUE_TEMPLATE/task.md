---
name: Task
about: A single, verifiable task
title: "[Task] "
labels: task
assignees: 
---

## Description
(1‑2 lines)

## Acceptance Criteria
- [ ]

## Links
- STATE_TRACKER.md:
- Docs:
