# PR Workflow (No‑Code Friendly)

- Create branch `docs/<topic>` → commit `.md` changes → push → open PR
- Use squash merge; see troubleshooting if blocked
