# Security Hardening (Minimums)

- Strong admin pw; 2FA later; SSH keys; HTTPS + HSTS
- Backups encrypted to GCS; test restore monthly
- Change logs on critical doctypes
