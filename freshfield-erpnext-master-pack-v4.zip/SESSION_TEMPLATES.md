# Session Templates

- 15‑min micro: pick 1 task → guide → 1 test → update state + changelog → commit
- 30‑min standard: plan, do, QA, log, PR
