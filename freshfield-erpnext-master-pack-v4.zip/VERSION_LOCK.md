# Version Lock (v15 + MariaDB 10.6)

- Pin Docker images to explicit v15 tags
- Avoid `latest`; patch dev → staging → prod
