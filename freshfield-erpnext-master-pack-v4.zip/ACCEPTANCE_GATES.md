# Acceptance Gates — Exit Phase 1

- Inventory variance thresholds met for 2 consecutive weeks
- Subcontracting dry run clean
- Multi‑currency & taxes correct
- Daily/weekly audits on schedule; no critical blockers
