# Role Matrix

- Now: Admin (System Manager + core modules)
- Future: Inventory Manager, Buyer, Accountant, Sales Manager, MFG Planner, Support
