# Definition of Done (Phase 1)

- Config applied + test passed
- State updated
- Changelog entry added
- Commit pushed / PR merged
