# Cursor Prompt Library — Phase 1

- **Architect**: turn spec into tasks + criteria
- **Setup Wizard**: Do/Verify checklists with citations
- **QA Lead**: run QA suite and list expected GL/stock effects
- **Drift Police**: block scope creep
- **Scribe**: append CHANGELOG entries
