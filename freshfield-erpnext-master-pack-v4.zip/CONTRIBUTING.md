# Contributing (Docs‑First)

- Markdown only for Phase 1
- Branch per topic; small commits; squash PRs
