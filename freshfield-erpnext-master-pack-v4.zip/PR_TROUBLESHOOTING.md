# PR Troubleshooting

- Push rejected → create branch / login
- Merge blocked → disable required reviews (solo) or approve with 2nd acct
- Checks failing → see markdown‑lint; edit and re‑push
- Conflicts → update branch; resolve; commit
