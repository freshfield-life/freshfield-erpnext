# CHANGELOG

## YYYY‑MM‑DD
**Summary:**  
- Steps:  
- Docs referenced:  
- Data changes:  
- QA results:  
- Issues:  
- Decisions:  
- Next actions:  
