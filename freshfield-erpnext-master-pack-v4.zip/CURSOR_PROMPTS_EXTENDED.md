# Cursor Prompts — Extended

- Progress Tracker (reads/writes `STATE_TRACKER.md`)
- Git/PR Flow coach
- Scope Guard (compare to spec, block creep)
