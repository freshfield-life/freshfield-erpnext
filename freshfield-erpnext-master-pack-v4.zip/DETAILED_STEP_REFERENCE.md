# Detailed Step Reference (Screen‑by‑Screen)

- System/Global defaults, Domain enablement
- Currency, Exchange, Price Lists, Item Prices
- Stock Settings (negative stock OFF), Warehouses
- Items (incl. subcontracted FG), BOMs (no ops)
- Subcontracting flow (PO → Transfer → Receipt) with expected ledger effects
