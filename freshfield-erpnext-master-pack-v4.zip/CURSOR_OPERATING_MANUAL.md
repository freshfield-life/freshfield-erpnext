# Cursor Operating Manual

- Pinned system prompt: obey guardrails, work one task at a time, Do/Verify with citations, update state & changelog, PRs only for code
