# Staging Clone & Restore

- `bench backup` on prod → copy to staging → `bench restore`
- Disable outbound email/payments on staging
- Snapshot before test loops
