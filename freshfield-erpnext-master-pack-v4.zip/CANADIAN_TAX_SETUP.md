# Canadian Tax Setup (Examples)

- Accounts: Sales Taxes Payable; GST/HST Recoverable
- Sales templates: HST 13% (ON), GST 5%, PST examples
- Purchase templates mirrored; verify GL postings
