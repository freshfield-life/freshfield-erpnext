# Project State Tracker

| Task | Status | Notes |
|---|---|---|
| Setup Wizard | NOT_STARTED | |
| Enable modules | NOT_STARTED | |
| Multi‑currency | NOT_STARTED | |
| Taxes | NOT_STARTED | |
| Warehouses | NOT_STARTED | |
| Items | NOT_STARTED | |
| BOMs | NOT_STARTED | |
| Subcontracting dry run | NOT_STARTED | |
| QA suite | NOT_STARTED | |
| Parallel run | NOT_STARTED | |
| Acceptance gates | NOT_STARTED | |
