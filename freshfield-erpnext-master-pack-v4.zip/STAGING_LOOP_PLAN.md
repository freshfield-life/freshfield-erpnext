# Staging Loop Plan

- Nightly clones, accelerated QA runs, synthetic transactions
- Audit stock & ledgers; fix → document → repeat
