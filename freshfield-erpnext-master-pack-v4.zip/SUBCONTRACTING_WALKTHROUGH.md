# Subcontracting Walkthrough

- Seed raw materials; create PO (Supply RM = Yes)
- Transfer Materials to Vendor‑<Name>
- Purchase Receipt for FG; optional Purchase Invoice for fee
- Verify Stock/GL effects and PO/PR linkages
