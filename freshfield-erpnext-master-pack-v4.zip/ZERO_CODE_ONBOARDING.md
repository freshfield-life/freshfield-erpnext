# Zero‑Code Onboarding (Cursor + GitHub)

- Clone repo in Cursor; drag this pack; commit once
- Keep 4 tabs pinned; use 15/30‑minute session scripts
- Update `STATE_TRACKER.md` + `CHANGELOG.md` every session; commit/PR
