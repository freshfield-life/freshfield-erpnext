# Audit Checklist

- v15 stable installed; Setup Wizard done; all modules enabled
- Multi‑currency & price lists created
- Tax templates created; sample invoices pass
- Warehouses & items created; FEFO if batches
- BOMs for subcontracted FG; dry run OK
- Backups configured; restore tested
- AI docs indexed; QA executed; gates green
