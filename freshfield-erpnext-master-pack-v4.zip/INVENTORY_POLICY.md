# Inventory Policy

- Warehouses: Raw Materials, Finished Goods, Vendor‑<Name>
- Items: stable codes; batches/expiry if needed; FEFO practice
- Controls: negative stock OFF; ABC counts; documented reasons for stock changes
- Subcontracting: FG flagged; BOMs w/o ops; PO→Transfer→Receipt
