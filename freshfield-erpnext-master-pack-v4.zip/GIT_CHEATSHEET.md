# Git Cheatsheet

status, checkout -b, add ., commit -m, push -u, open PR, pull --rebase, resolve conflicts
