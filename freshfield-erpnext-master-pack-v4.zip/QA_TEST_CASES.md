# QA Test Cases — Phase 1

1) Multi‑currency: CAD vs USD invoices (GL postings correct)
2) Purchase tax: HST/GST template postings
3) Subcontracting: PO → Transfer Materials → Purchase Receipt (valuation correct)
4) Module sanity: open core screens without errors
