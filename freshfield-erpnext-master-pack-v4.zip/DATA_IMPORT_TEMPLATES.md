# Data Import Templates

- Items: Item Code, Name, Group, Is Stock Item, UoM, Barcode, Batch/Expiry, Default WH, Supply RM for Purchase
- Opening Stock: Item, Warehouse, Qty, Valuation Rate, Batch/Expiry
- Price List: List, Currency, Item, UoM, Rate
- Batches: Item, Batch ID, Qty, Warehouse, Expiry
