# ERPNext UI Paths (Quick Nav)

System Settings, Global Defaults, Domain Settings, Currency, Currency Exchange, Price List, Item Price, Item, Warehouse, Stock Settings, Stock Entry, BOM, Purchase Order, Purchase Receipt, Sales/Purchase Invoices, GL, Stock Balance/Ledger
