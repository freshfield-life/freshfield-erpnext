# Repo Settings (Solo Admin)

- Default branch `main` (protected)
- Require PRs; approvals OFF; markdown‑lint check ON (soft)
- Allow squash merge
