# Parallel‑Run Checklist

- Daily: A‑item variances, stock ledger anomalies, batch expiries
- Weekly: sell‑through by SKU, PO/receipt realism, variance trend
- Data discipline: negative stock OFF; ABC cycle counts; two‑person review
